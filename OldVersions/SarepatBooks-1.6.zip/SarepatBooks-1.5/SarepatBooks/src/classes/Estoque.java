/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Gabriel Barbosa
 */
public class Estoque {
    private int codigo;
    private int quantidade;
    private Livro livro;
    
    public Estoque(int codigo, int quantidade, Livro livro){
        this.codigo = codigo;
        this.quantidade = quantidade;
        this.livro = livro;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the livro
     */
    public Livro getLivro() {
        return livro;
    }

    /**
     * @param livro the livro to set
     */
    public void setLivro(Livro livro) {
        this.livro = livro;
    }
    
    @Override
    public String toString(){
        return getCodigo()+" | "+getQuantidade()+" | "+getLivro().getCodigo();
    }
}
