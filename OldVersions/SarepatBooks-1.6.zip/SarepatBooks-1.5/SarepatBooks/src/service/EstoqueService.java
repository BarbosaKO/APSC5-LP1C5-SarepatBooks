/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.*;
import classes.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author gabri
 */
public class EstoqueService {
    public void adicionarNovoLivro(String obra, int edicao, java.util.Date ano, int numPaginas, String idioma, String pais, String isbn, Double preco, String nomeEditora, String nomeGenero, String nomeAutor, int livroQuantidade){
        EditoraDAO editoraDAO = new EditoraDAO();
        Editora editora = new Editora(editoraDAO.findMaxId()+1, nomeEditora);
        editoraDAO.criar(editora);
        
        LivroDAO livroDAO = new LivroDAO();
        Livro livro = new Livro(livroDAO.findMaxId()+1,obra,edicao,ano,numPaginas,idioma,pais,isbn,preco,editora);
        livroDAO.criar(livro);
        
        GeneroDAO generoDAO = new GeneroDAO();
        Genero genero = new Genero(generoDAO.findMaxId()+1,livro,nomeGenero);
        generoDAO.criar(genero);
        
        AutorDAO autorDAO = new AutorDAO();
        Autor autor = new Autor(autorDAO.findMaxId()+1,livro,nomeAutor);
        autorDAO.criar(autor);
        
        EstoqueDAO estoqueDAO = new EstoqueDAO();
        Estoque estoque = new Estoque(estoqueDAO.findMaxId()+1,livroQuantidade,livro);
        estoqueDAO.criar(estoque);
    }
    
    
    
}
